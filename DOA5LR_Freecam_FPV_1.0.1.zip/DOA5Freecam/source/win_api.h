/* Minimal Win32 declarations: this build does not require the Windows SDK. */
#pragma once
typedef unsigned long DWORD;
typedef long LONG;
typedef int BOOL;
typedef unsigned char BYTE;
typedef unsigned short WCHAR;
typedef void *HANDLE;
typedef void *HMODULE;
typedef void *PVOID;
typedef unsigned long SIZE_T;
#define API __stdcall
#define DLL __declspec(dllimport)
#define TRUE 1
#define FALSE 0
#define NULL ((void*)0)
#define INVALID ((HANDLE)-1)
#define INFINITE 0xffffffffUL
typedef DWORD (API *THREADPROC)(void*);
typedef BOOL (API *INITPROC)(void*, void*, void**);
typedef struct { DWORD size, usage, tid, pid; LONG priority, delta; DWORD flags; } THREADENTRY;
DLL BOOL API DisableThreadLibraryCalls(HMODULE);
DLL DWORD API GetModuleFileNameW(HMODULE,WCHAR*,DWORD);
DLL DWORD API GetSystemDirectoryW(WCHAR*,DWORD);
DLL HMODULE API LoadLibraryW(const WCHAR*);
DLL HMODULE API LoadLibraryExW(const WCHAR*,HANDLE,DWORD);
DLL PVOID API GetProcAddress(HMODULE,const char*);
DLL BOOL API InitOnceExecuteOnce(void**,INITPROC,PVOID,PVOID*);
DLL DWORD API GetCurrentProcessId(void);
DLL DWORD API GetCurrentThreadId(void);
DLL HANDLE API GetCurrentProcess(void);
DLL HANDLE API CreateThread(PVOID,SIZE_T,THREADPROC,PVOID,DWORD,DWORD*);
DLL HANDLE API OpenThread(DWORD,BOOL,DWORD);
DLL DWORD API SuspendThread(HANDLE);
DLL DWORD API ResumeThread(HANDLE);
DLL DWORD API WaitForSingleObject(HANDLE,DWORD);
DLL BOOL API CloseHandle(HANDLE);
DLL HANDLE API CreateToolhelp32Snapshot(DWORD,DWORD);
DLL BOOL API Thread32First(HANDLE,THREADENTRY*);
DLL BOOL API Thread32Next(HANDLE,THREADENTRY*);
DLL BOOL API VirtualProtect(PVOID,SIZE_T,DWORD,DWORD*);
DLL BOOL API FlushInstructionCache(HANDLE,const void*,SIZE_T);
DLL BOOL API ReadProcessMemory(HANDLE,const void*,void*,SIZE_T,SIZE_T*);
DLL DWORD API GetFileAttributesW(const WCHAR*);
DLL void API ExitProcess(DWORD);
DLL void API Sleep(DWORD);
DLL HANDLE API CreateFileW(const WCHAR*,DWORD,DWORD,PVOID,DWORD,DWORD,HANDLE);
DLL BOOL API WriteFile(HANDLE,const void*,DWORD,DWORD*,PVOID);

/* lib.exe's name-only imports plus aliases preserve Win32 stdcall decoration. */
#define IMPORT_ALIAS(name,bytes) __pragma(comment(linker,"/alternatename:__imp__" #name "@" #bytes "=__imp__" #name))
IMPORT_ALIAS(DisableThreadLibraryCalls,4)
IMPORT_ALIAS(GetModuleFileNameW,12)
IMPORT_ALIAS(GetSystemDirectoryW,8)
IMPORT_ALIAS(LoadLibraryW,4)
IMPORT_ALIAS(LoadLibraryExW,12)
IMPORT_ALIAS(GetProcAddress,8)
IMPORT_ALIAS(InitOnceExecuteOnce,16)
IMPORT_ALIAS(GetCurrentProcessId,0)
IMPORT_ALIAS(GetCurrentThreadId,0)
IMPORT_ALIAS(GetCurrentProcess,0)
IMPORT_ALIAS(CreateThread,24)
IMPORT_ALIAS(OpenThread,12)
IMPORT_ALIAS(SuspendThread,4)
IMPORT_ALIAS(ResumeThread,4)
IMPORT_ALIAS(WaitForSingleObject,8)
IMPORT_ALIAS(CloseHandle,4)
IMPORT_ALIAS(CreateToolhelp32Snapshot,8)
IMPORT_ALIAS(Thread32First,8)
IMPORT_ALIAS(Thread32Next,8)
IMPORT_ALIAS(VirtualProtect,16)
IMPORT_ALIAS(FlushInstructionCache,12)
IMPORT_ALIAS(ReadProcessMemory,20)
IMPORT_ALIAS(GetFileAttributesW,4)
IMPORT_ALIAS(ExitProcess,4)
IMPORT_ALIAS(Sleep,4)
IMPORT_ALIAS(CreateFileW,28)
IMPORT_ALIAS(WriteFile,20)
