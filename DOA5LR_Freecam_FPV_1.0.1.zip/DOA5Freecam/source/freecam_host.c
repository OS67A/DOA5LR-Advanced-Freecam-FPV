/* DOA5LR drop-in host. No CRT, console, child process, or disk game patch. */
#include "win_api.h"
#include "winmm_exports.h"

static HMODULE self_module, real_winmm;
static PVOID system_once;
static DWORD watcher_tid;
static HANDLE controller_handle;
static volatile BOOL boot_allowed;
static WCHAR root[32768];
PVOID forward_targets[EXPORT_COUNT];

typedef struct { BYTE *site; DWORD size; BYTE old[16], replacement[16]; } PATCH;
static PATCH patches[96];
static DWORD patch_count, zero_count;
static DWORD *zeros[8];

static void __cdecl missing_system_export(void) { ExitProcess(0xc0000139); }

static DWORD length(const WCHAR *s) { DWORD n=0; while(s[n]) ++n; return n; }
static BOOL append(WCHAR *s,const WCHAR *tail) {
    DWORD n=length(s),i=0;
    if(n+length(tail)>=32768) return FALSE;
    while(tail[i]) { s[n+i]=tail[i]; ++i; } s[n+i]=0; return TRUE;
}
static void copy_w(WCHAR *out,const WCHAR *in) { DWORD i=0; do {out[i]=in[i];}while(in[i++]); }
static BOOL equal(const BYTE *a,const BYTE *b,DWORD n) { DWORD i;for(i=0;i<n;++i)if(a[i]!=b[i])return FALSE;return TRUE; }
static void copy_b(BYTE *out,const BYTE *in,DWORD n) { DWORD i;for(i=0;i<n;++i)out[i]=in[i]; }

/* Open every handle before suspending anything. Once paused, use only kernel
   memory APIs and preallocated storage, avoiding other threads' heap locks. */
typedef struct { HANDLE handles[512]; DWORD count; } PAUSE;
static BOOL pause_others(PAUSE *p) {
    HANDLE snapshot; THREADENTRY e; DWORD me=GetCurrentThreadId(),pid=GetCurrentProcessId(),i;
    p->count=0; snapshot=CreateToolhelp32Snapshot(4,0); if(snapshot==INVALID)return FALSE;
    e.size=sizeof(e);
    if(Thread32First(snapshot,&e)) do {
        if(e.pid==pid && e.tid!=me && e.tid!=watcher_tid) {
            HANDLE h=OpenThread(0x0002|0x100000,FALSE,e.tid);
            if(!h) { CloseHandle(snapshot);for(i=0;i<p->count;++i)CloseHandle(p->handles[i]);return FALSE; }
            if(p->count==512){CloseHandle(h);CloseHandle(snapshot);for(i=0;i<p->count;++i)CloseHandle(p->handles[i]);return FALSE;}
            p->handles[p->count++]=h;
        }
        e.size=sizeof(e);
    } while(Thread32Next(snapshot,&e));
    CloseHandle(snapshot);
    for(i=0;i<p->count;++i) {
        if(SuspendThread(p->handles[i])==0xffffffffUL) {
            DWORD j;for(j=0;j<i;++j)ResumeThread(p->handles[j]);
            for(j=0;j<p->count;++j)CloseHandle(p->handles[j]);return FALSE;
        }
    }
    return TRUE;
}
static void resume_others(PAUSE *p) {
    DWORD i;for(i=0;i<p->count;++i)ResumeThread(p->handles[i]);
    for(i=0;i<p->count;++i)CloseHandle(p->handles[i]);
}
static BOOL write_code(BYTE *site,const BYTE *value,DWORD size) {
    DWORD old,ignored;BOOL ok;
    if(!VirtualProtect(site,size,0x40,&old))return FALSE;
    copy_b(site,value,size);ok=FlushInstructionCache(GetCurrentProcess(),site,size);
    if(!VirtualProtect(site,size,old,&ignored))ok=FALSE;
    return ok;
}
BOOL API FC_RegisterPatch(BYTE *site,const BYTE *old,const BYTE *replacement,DWORD size) {
    DWORD i;PATCH *p;
    if(!site||!size||size>16)return FALSE;
    for(i=0;i<patch_count;++i) if(patches[i].site==site)
        return patches[i].size==size&&equal(patches[i].old,old,size)&&equal(patches[i].replacement,replacement,size);
    if(patch_count==96)return FALSE;
    p=&patches[patch_count++];p->site=site;p->size=size;
    copy_b(p->old,old,size);copy_b(p->replacement,replacement,size);return TRUE;
}
BOOL API FC_RegisterZero(DWORD *address) {
    DWORD i;for(i=0;i<zero_count;++i)if(zeros[i]==address)return TRUE;
    if(zero_count==8)return FALSE;zeros[zero_count++]=address;return TRUE;
}
BOOL API FC_Patch(BYTE *site,const BYTE *expected,const BYTE *replacement,DWORD size) {
    PAUSE p;BOOL ok;
    if(!site||!size||size>16||!pause_others(&p))return FALSE;
    ok=equal(site,expected,size)&&write_code(site,replacement,size);
    resume_others(&p);return ok;
}
BOOL API FC_RestoreAll(void) {
    PAUSE pause;DWORD i;BOOL ok=TRUE;
    if(!patch_count)return TRUE;
    if(!pause_others(&pause))return FALSE;
    for(i=0;i<zero_count;++i)*zeros[i]=0;
    for(i=patch_count;i>0;--i){PATCH *p=&patches[i-1];
        if(equal(p->site,p->replacement,p->size)&&!write_code(p->site,p->old,p->size))ok=FALSE;
        /* Preserve foreign changes, exactly as the external recovery did. */
    }
    resume_others(&pause);return ok;
}

static DWORD API controller(void *unused) {
    static WCHAR home[32768],path[32768];HMODULE python;
    void (__cdecl *set_home)(const WCHAR*);
    void (__cdecl *set_path)(const WCHAR*);
    void (__cdecl *initialize)(void);
    int (__cdecl *run)(const char*);
    (void)unused;
    if(!boot_allowed)return 1;
    copy_w(home,root);append(home,L"\\DOA5Freecam\\runtime");
    copy_w(path,home);append(path,L"\\python312.dll");
    python=LoadLibraryExW(path,NULL,8);if(!python)return 2;
    set_home=(void*)GetProcAddress(python,"Py_SetPythonHome");
    set_path=(void*)GetProcAddress(python,"Py_SetPath");
    initialize=(void*)GetProcAddress(python,"Py_Initialize");
    run=(void*)GetProcAddress(python,"PyRun_SimpleString");
    if(!set_home||!set_path||!initialize||!run)return 3;
    copy_w(path,home);append(path,L"\\python312.zip;");append(path,home);
    append(path,L";");append(path,root);append(path,L"\\DOA5Freecam\\scripts");
    set_home(home);set_path(path);initialize();
    return run("import sys; sys.dont_write_bytecode=True; import doa5_mod_app; doa5_mod_app.run()") ? 4 : 0;
}
static DWORD API watchdog(void *unused) {
    (void)unused;WaitForSingleObject(controller_handle,INFINITE);
    FC_RestoreAll();CloseHandle(controller_handle);return 0;
}
static void start_mod(void) {
    static WCHAR game[32768],check[32768];DWORD n,i;HANDLE watcher;
    n=GetModuleFileNameW(NULL,game,32768);if(!n||n>=32768)return;
    i=n;while(i&&game[i-1]!='\\'&&game[i-1]!='/')--i;
    /* No host activity in launchers or other programs loading this proxy. */
    if(length(game+i)!=8)return;
    if((game[i]|32)!='g'||(game[i+1]|32)!='a'||(game[i+2]|32)!='m'||(game[i+3]|32)!='e'||game[i+4]!='.'||
       (game[i+5]|32)!='e'||(game[i+6]|32)!='x'||(game[i+7]|32)!='e')return;
    copy_w(root,game);root[i?i-1:0]=0;
    copy_w(check,root);append(check,L"\\DOA5Freecam\\disabled.flag");
    if(GetFileAttributesW(check)!=0xffffffffUL)return;
    copy_w(check,root);append(check,L"\\DOA5Freecam\\runtime\\python312.dll");
    if(GetFileAttributesW(check)==0xffffffffUL)return;
    controller_handle=CreateThread(NULL,0,controller,NULL,4,NULL);
    if(!controller_handle)return;
    watcher=CreateThread(NULL,0,watchdog,NULL,0,&watcher_tid);
    boot_allowed=watcher!=NULL;
    ResumeThread(controller_handle);
    if(watcher)CloseHandle(watcher);else CloseHandle(controller_handle);
}
static BOOL API initialize_system(void *once,void *parameter,void **context) {
    static WCHAR system[32768];DWORD i,n;
    (void)once;(void)parameter;(void)context;
    n=GetSystemDirectoryW(system,32768);if(!n||n>=32768)ExitProcess(0xc0000135);
    append(system,L"\\winmm.dll");real_winmm=LoadLibraryW(system);
    if(!real_winmm)ExitProcess(0xc0000135);
    for(i=0;i<EXPORT_COUNT;++i){
        forward_targets[i]=GetProcAddress(real_winmm,export_names[i]?export_names[i]:(const char*)export_ordinals[i]);
        /* An older Windows release may omit an unused private export. Only
           fail if a caller actually requests it; the game's five public timer
           APIs are present on every supported Windows version. */
        if(!forward_targets[i])forward_targets[i]=missing_system_export;
    }
    start_mod();return TRUE;
}
void __cdecl FC_Resolve(void) { InitOnceExecuteOnce(&system_once,initialize_system,NULL,NULL); }
/* Forwarder calls preserve every argument and calling convention. */
__declspec(naked) void FC_Dispatch(void) {
    __asm { pushfd }
    __asm { pushad }
    __asm { call FC_Resolve }
    __asm { mov eax,[esp+36] }
    __asm { mov eax,forward_targets[eax*4] }
    __asm { mov [esp+28],eax }
    __asm { popad }
    __asm { popfd }
    __asm { add esp,4 }
    __asm { jmp eax }
}
BOOL API DllMain(HMODULE instance,DWORD reason,void *reserved) {
    (void)reserved;if(reason==1){self_module=instance;DisableThreadLibraryCalls(instance);}return TRUE;
}
