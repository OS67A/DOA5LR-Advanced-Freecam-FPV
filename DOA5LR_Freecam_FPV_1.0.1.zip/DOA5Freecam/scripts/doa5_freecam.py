"""Fly, orbit, and first-person camera for offline matches on Steam DOA5LR 1.10C."""

import argparse
from contextlib import contextmanager
import ctypes as ct
from ctypes import wintypes as wt
from dataclasses import dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import struct
import time

from doa5_process import read, u32, bind, open_game, FIELDS, PLAYER_ANCHOR, native_helper
from doa5_head_visibility import HeadOverlapGuard, installed_head_filter
from doa5_recovery import RecoveryJournal
from doa5_camera_floor import FloorGuard


IMAGE_HASH = "88d12d42ba49ac696de1acbb25da12615726e8b6259fc24dd6e7d4d939f89bbc"
PUBLISH_RVA = 0x2C2B25
PUBLISH = bytes.fromhex("E8 56 B4 00 00")
COPY_RVA = 0x2CDF80
COPY_HEAD = bytes.fromhex("55 8B EC 8B 45 08 B2 01 85 C0 0F 84 AE 00 00 00")
CAMERA_RVA = 0xFC7310
CAMERA_VTABLE_RVA = 0x98CC00
CAMERA_SIZE = 0xF4
POSE_OFFSET = 0x84
PLAYER_ANCHOR_RVA = 0xF98FB8
PLAYER_ROOT_OFFSETS = (FIELDS["p1_x"][0], FIELDS["p2_x"][0])
PLAYER_ID_OFFSETS = (FIELDS["p1_character"][0], FIELDS["p2_character"][0])
PLAYER_MOVE_TYPE_OFFSETS = (FIELDS["p1_move_type"][0], FIELDS["p2_move_type"][0])
THROW_ATTACKER_MOVE_TYPE = 4
PLAYER_HEAD_RVAS = (0xFC9320, 0xFC9920)
JOINT_MATRIX_BYTES = 64
ORBIT_PIVOT_HEIGHT = 0.9
FIRST_PERSON_NEAR = 0.002
FIRST_PERSON_FOV = math.radians(60)  # Vertical FOV; about 91.5 degrees at 16:9.
# Native rigs' bind-pose eye midpoint above the toe bones, in game units.
# Hayabusa uses the head bone plus the roster's typical head-to-eye offset.
RIG_EYE_HEIGHT = {
    0: 1.593, 1: 1.507, 2: 1.590, 3: 1.591, 4: 1.575, 5: 1.472,
    6: 1.471, 7: 1.505, 8: 1.662, 9: 1.749, 10: 1.478, 11: 1.591,
    12: 1.478, 13: 1.471, 14: 1.470, 15: 1.503, 16: 1.472, 19: 1.589,
    20: 1.558, 21: 1.478, 24: 1.663, 29: 1.589, 30: 1.480, 31: 1.590,
    32: 1.553, 33: 1.477, 39: 1.476, 40: 1.504, 41: 1.590, 42: 1.321,
    43: 1.472, 44: 1.476, 45: 1.343, 46: 1.748, 47: 1.502, 48: 1.469,
}
STANCE_HEIGHT_ADJUSTMENT = 0.08
# Eye midpoint in the head bone's local Y/Z axes, derived from the native face rigs.
HEAD_EYE_OFFSETS = {
    0: (.0732, .0713), 1: (.0702, .0666), 2: (.0702, .0723), 3: (.0706, .0695),
    5: (.0564, .0590), 6: (.0727, .0760), 7: (.0683, .0642), 8: (.0699, .0745),
    9: (.0732, .0909), 10: (.0575, .0614), 11: (.0706, .0695), 12: (.0584, .0646),
    13: (.0556, .0583), 14: (.0712, .0605), 15: (.0666, .0634), 16: (.0564, .0590),
    19: (.0693, .0723), 20: (.0605, .0632), 21: (.0577, .0573), 24: (.0713, .0758),
    29: (.0693, .0723), 30: (.0599, .0635), 31: (.0702, .0726), 32: (.0560, .0682),
    33: (.0566, .0657), 39: (.0564, .0650), 40: (.0677, .0720), 41: (.0702, .0702),
    42: (.0526, .0580), 43: (.0564, .0590), 44: (.0564, .0637), 45: (.0748, .0592),
    46: (.0723, .0799), 47: (.0656, .0660), 48: (.0489, .0618),
}
PAGE_SIZE = 4096
CONTROL_OFFSET = PAGE_SIZE
HITS_OFFSET = CONTROL_OFFSET + 4
SLOT_OFFSET = CONTROL_OFFSET + 16


def position_bytes(eye, forward, distance, roll, near, fov=0.0):
    aim = tuple(value + distance * axis for value, axis in zip(eye, forward))
    return struct.pack("<15f", *eye, 0, *aim, 0, 0, 1, 0, 0, roll, near, fov)


def direction(yaw, pitch):
    sine, cosine = math.sin(yaw), math.cos(yaw)
    tilt, level = math.sin(pitch), math.cos(pitch)
    return (sine * level, tilt, cosine * level), (-sine * tilt, level, -cosine * tilt)


def look_angles(vector):
    x, y, z = vector
    return math.atan2(x, z), math.atan2(y, math.hypot(x, z))


def fighter_pivots(kernel, handle, base):
    anchor = base + PLAYER_ANCHOR_RVA
    if read(kernel, handle, anchor, len(PLAYER_ANCHOR)) != PLAYER_ANCHOR:
        return None
    first, second = PLAYER_ROOT_OFFSETS
    roots = read(kernel, handle, anchor + first, second - first + 16)
    if roots is None:
        return None
    players = [struct.unpack_from("<4f", roots, offset) for offset in (0, second - first)]
    if not all(w == 1.0 and all(math.isfinite(v) and abs(v) < 10000 for v in (x, y, z))
               for x, y, z, w in players):
        return None
    return tuple((x, y + ORBIT_PIVOT_HEIGHT, z) for x, y, z, _ in players)


def estimated_eye_height(kernel, handle, base, player):
    character = read(kernel, handle, base + PLAYER_ANCHOR_RVA + PLAYER_ID_OFFSETS[player], 1)
    bind_height = RIG_EYE_HEIGHT.get(character[0] if character else None, 1.47)
    return bind_height - STANCE_HEIGHT_ADJUSTMENT


def throw_gaze_target(kernel, handle, base, player, pivots):
    move_type = read(kernel, handle, base + PLAYER_ANCHOR_RVA + PLAYER_MOVE_TYPE_OFFSETS[player], 1)
    if move_type != bytes((THROW_ATTACKER_MOVE_TYPE,)):
        return None
    opponent = 1 - player
    pivot = pivots[opponent]
    torso_rva = PLAYER_HEAD_RVAS[opponent] - JOINT_MATRIX_BYTES
    joints = read(kernel, handle, base + torso_rva, 2 * JOINT_MATRIX_BYTES)
    if joints is not None:
        torso = struct.unpack_from("<16f", joints)
        head = struct.unpack_from("<16f", joints, JOINT_MATRIX_BYTES)
        if usable_joint(torso, pivot):
            center = torso[12:15]
            if usable_joint(head, pivot) and math.dist(center, head[12:15]) < 0.8:
                # Stay on the upper torso as the opponent bends or rolls.
                return tuple(chest + 0.30 * (neck - chest)
                             for chest, neck in zip(center, head[12:15]))
            return center
        if usable_joint(head, pivot):
            return tuple(pos - 0.20 * up for pos, up in zip(head[12:15], head[4:7]))
    x, y, z = pivot
    height = estimated_eye_height(kernel, handle, base, opponent)
    return x, y - ORBIT_PIVOT_HEIGHT + height - 0.30, z


def head_eyes(kernel, handle, base, pivots):
    first, second = PLAYER_HEAD_RVAS
    heads = read(kernel, handle, base + first, second - first + 64)
    if heads is None:
        return None, None
    ids_start, ids_end = PLAYER_ID_OFFSETS
    ids = read(kernel, handle, base + PLAYER_ANCHOR_RVA + ids_start, ids_end - ids_start + 1)
    characters = (ids[0], ids[-1]) if ids else (None, None)
    return tuple(
        eye_from_head(struct.unpack_from("<16f", heads, offset), character, pivot)
        for offset, character, pivot in zip((0, second - first), characters, pivots)
    )


def usable_joint(matrix, pivot):
    return (all(map(math.isfinite, matrix))
            and all(abs(matrix[i]) <= 0.001 for i in (3, 7, 11))
            and abs(matrix[15] - 1) <= 0.001
            and all(abs(math.hypot(*matrix[i:i + 3]) - 1) <= 0.05 for i in (0, 4, 8))
            and math.dist(matrix[12:15], pivot) <= 3)


def eye_from_head(matrix, character, pivot):
    if not usable_joint(matrix, pivot):
        return None
    up, forward, head = matrix[4:7], matrix[8:11], matrix[12:15]
    eye_y, eye_z = HEAD_EYE_OFFSETS.get(character, (.063, .065))
    eye = tuple(pos + eye_y * u + eye_z * z for pos, u, z in zip(head, up, forward))
    return eye, (matrix[0:3], up, forward)


@dataclass
class Orbit:
    player: int
    yaw: float
    pitch: float
    radius: float
    aim_offset: tuple[float, float]
    transition: float = 0.2
    height: float = 0.0

    @classmethod
    def from_view(cls, player, pivot, eye, yaw, pitch):
        delta = tuple(center - pos for center, pos in zip(pivot, eye))
        radius = math.hypot(*delta)
        orbit_yaw, orbit_pitch = look_angles(delta) if radius > 1e-5 else (yaw, pitch)
        # Interpolate the aim while keeping the camera position on target changes.
        offset = (math.remainder(yaw - orbit_yaw, math.tau),
                  math.remainder(pitch - orbit_pitch, math.tau))
        return cls(player, orbit_yaw, orbit_pitch, max(0.15, radius), offset)

    def view(self, pivot):
        center = (pivot[0], pivot[1] + self.height, pivot[2])
        forward, _ = direction(self.yaw, self.pitch)
        eye = tuple(pos - self.radius * axis for pos, axis in zip(center, forward))
        blend = self.transition / 0.2
        return (eye, self.yaw + blend * self.aim_offset[0],
                self.pitch + blend * self.aim_offset[1], self.radius)


@dataclass
class FirstPerson:
    player: int
    heading: float
    turn: float = 0.0
    pitch: float = 0.0
    last_head_axes: tuple | None = None
    last_eye_offset: tuple | None = None

    def view(self, pivots, eye_height, eyes=(None, None), trim=0.0):
        pivot = pivots[self.player]
        animated_eye = eyes[self.player]
        if animated_eye is not None:
            point, self.last_head_axes = animated_eye
            self.last_eye_offset = tuple(pos - origin for pos, origin in zip(point, pivot))
        if self.last_head_axes is not None:
            point = tuple(pos + offset for pos, offset in zip(pivot, self.last_eye_offset))
            local_forward, local_up = direction(self.turn, self.pitch)
            world_axes = tuple(zip(*self.last_head_axes))
            world_forward = tuple(math.sumprod(local_forward, axis) for axis in world_axes)
            world_up = tuple(math.sumprod(local_up, axis) for axis in world_axes)
            self.heading, elevation = look_angles(world_forward)
            _, level_up = direction(self.heading, elevation)
            level_right = (-math.cos(self.heading), 0, math.sin(self.heading))
            head_roll = math.atan2(math.sumprod(world_up, level_right),
                                   math.sumprod(world_up, level_up))
            eye = (point[0], point[1] + trim, point[2])
            return eye, self.heading, elevation, 1.0, head_roll

        x, y, z = pivot
        other_x, _, other_z = pivots[1 - self.player]
        dx, dz = other_x - x, other_z - z
        if math.hypot(dx, dz) > 0.05:
            self.heading = math.atan2(dx, dz)
        # Use the fight axis and a point just in front of the estimated eyes.
        eye = (x + 0.20 * math.sin(self.heading), y - ORBIT_PIVOT_HEIGHT + eye_height + trim,
               z + 0.20 * math.cos(self.heading))
        return eye, self.heading + self.turn, self.pitch, 1.0, 0.0


def camera_payload(eye, yaw, pitch, distance, roll, near=0.0, fov=0.0):
    # CameraInfo builds its view from world up, which flips its horizontal axis
    # past vertical. Add half a turn of roll there to keep the view continuous.
    if abs(math.cos(pitch)) < 0.0001:
        pitch = math.copysign(math.pi / 2 - 0.0001, math.sin(pitch))
    if math.cos(pitch) < 0:
        roll += math.pi
    forward, _ = direction(yaw, pitch)
    return position_bytes(eye, forward, distance, math.remainder(roll, math.tau), near, fov)


def relative_call(address, target):
    return b"\xe8" + struct.pack("<I", (target - address - 5) & 0xFFFFFFFF)


def trampoline(address, base, head_control=0):
    # Original callee uses ECX = destination, one stack argument, and RET 4.
    code = bytes.fromhex("51 FF 74 24 08")  # save ECX and pass a copy of the argument
    code += relative_call(address + len(code), base + COPY_RVA)
    code += bytes.fromhex("9C 60 8B 7C 24 24")  # save flags/registers, load saved ECX
    cameras = base + CAMERA_RVA
    code += b"\x81\xff" + struct.pack("<I", cameras)       # cmp edi, camera[0]
    code += bytes.fromhex("74 08")
    code += b"\x81\xff" + struct.pack("<I", cameras + CAMERA_SIZE)
    code += b"\x75\x00"
    other_camera = len(code) - 1
    code += b"\x8b\x35" + struct.pack("<I", address + CONTROL_OFFSET)
    code += bytes.fromhex("85 F6 74 00")
    disabled = len(code) - 1
    code += bytes.fromhex("81 C7 84 00 00 00 B9 0D 00 00 00 FC F3 A5")
    # EDI now points to CameraInfo+0xB8. A zero payload keeps the engine's near plane.
    code += bytes.fromhex("AD 85 C0 74 03 89 47 04")
    # EDI remains at CameraInfo+0xB8. A zero FOV preserves the engine's value.
    code += bytes.fromhex('AD 85 C0 74 02 89 07')
    if head_control:
        # The following uint selects a prebuilt immutable head-filter table.
        # Publish it in the same game callback as the corrected camera position.
        code += b"\xad\xa3" + struct.pack("<I", head_control)
    code += b"\xff\x05" + struct.pack("<I", address + HITS_OFFSET)
    code = bytearray(code)
    code[other_camera] = len(code) - other_camera - 1
    code[disabled] = len(code) - disabled - 1
    code += bytes.fromhex("61 9D 8D 64 24 04 C2 04 00")
    return bytes(code)


class GameExited(RuntimeError):
    """The game finished exiting while a process-memory operation was pending."""


class GameMemory:
    def __init__(self, kernel, pid):
        self.native = native_helper() if pid == os.getpid() else None
        open_process = bind(kernel, "OpenProcess", wt.HANDLE, wt.DWORD, wt.BOOL, wt.DWORD)
        self.handle = open_process(0x100000 | 0x0010 | 0x0020 | 0x0008 | 0x0400 | 0x0800,
                                   False, pid)
        if not self.handle:
            raise ct.WinError(ct.get_last_error())
        self.close = bind(kernel, "CloseHandle", wt.BOOL, wt.HANDLE)
        self.write_memory = bind(kernel, "WriteProcessMemory", wt.BOOL, wt.HANDLE,
                                 ct.c_void_p, ct.c_void_p, ct.c_size_t, ct.POINTER(ct.c_size_t))
        self.protect_memory = bind(kernel, "VirtualProtectEx", wt.BOOL, wt.HANDLE,
                                   ct.c_void_p, ct.c_size_t, wt.DWORD, ct.POINTER(wt.DWORD))
        self.allocate_memory = bind(kernel, "VirtualAllocEx", ct.c_void_p, wt.HANDLE,
                                    ct.c_void_p, ct.c_size_t, wt.DWORD, wt.DWORD)
        self.free_memory = bind(kernel, "VirtualFreeEx", wt.BOOL, wt.HANDLE,
                                ct.c_void_p, ct.c_size_t, wt.DWORD)
        self.flush = bind(kernel, "FlushInstructionCache", wt.BOOL, wt.HANDLE,
                          ct.c_void_p, ct.c_size_t)
        self.wait = bind(kernel, "WaitForSingleObject", wt.DWORD, wt.HANDLE, wt.DWORD)
        ntdll = ct.WinDLL("ntdll")
        self.suspend = bind(ntdll, "NtSuspendProcess", ct.c_long, wt.HANDLE)
        self.resume = bind(ntdll, "NtResumeProcess", ct.c_long, wt.HANDLE)

    def write(self, address, data):
        size = ct.c_size_t()
        if not self.write_memory(self.handle, address, data, len(data), ct.byref(size)):
            error = ct.get_last_error()
            # Windows can revoke write access during teardown before signaling
            # the process handle. Treat that race as a normal game shutdown.
            if self.wait(self.handle, 1000) == 0:
                raise GameExited('The game process exited.')
            raise ct.WinError(error)
        if size.value != len(data):
            raise RuntimeError(f"Short process write at 0x{address:X}")

    def protect(self, address, size, protection):
        old = wt.DWORD()
        if not self.protect_memory(self.handle, address, size, protection, ct.byref(old)):
            raise ct.WinError(ct.get_last_error())
        return old.value

    def exited(self):
        result = self.wait(self.handle, 0)
        if result not in (0, 0x102):
            raise ct.WinError(ct.get_last_error())
        return result == 0

    @contextmanager
    def paused(self):
        if self.native:
            raise RuntimeError('In-process patches must use the native patch guard')
        if self.suspend(self.handle):
            if self.wait(self.handle, 1000) == 0:
                raise GameExited('The game process exited.')
            raise RuntimeError("Could not suspend DOA5LR to update its call instruction")
        try:
            yield
        finally:
            if self.resume(self.handle):
                if self.wait(self.handle, 1000) == 0:
                    raise GameExited('The game process exited.')
                raise RuntimeError("Could not resume DOA5LR after updating its call instruction")

    def patch(self, site, expected, replacement, kernel):
        if self.native:
            if not self.native.FC_Patch(site, expected, replacement, len(expected)):
                raise RuntimeError('Could not safely update the game instruction')
            return
        with self.paused():
            if read(kernel, self.handle, site, len(expected)) != expected:
                raise RuntimeError("The camera instruction changed. Restart the game before retrying.")
            old = self.protect(site, len(replacement), 0x40)
            try:
                self.write(site, replacement)
                if not self.flush(self.handle, site, len(replacement)):
                    raise ct.WinError(ct.get_last_error())
            except BaseException:
                self.write(site, expected)
                self.flush(self.handle, site, len(expected))
                raise
            finally:
                self.protect(site, len(replacement), old)


class Camera:
    def __init__(self, memory, address, head_visibility=None):
        self.memory = memory
        self.address = address
        self.slot = 0
        self.head_visibility = head_visibility

    def publish(self, pose):
        if self.head_visibility is not None:
            pose += struct.pack('<I', self.head_visibility.selected)
        self.slot ^= 1
        slot_address = self.address + SLOT_OFFSET + self.slot * len(pose)
        self.memory.write(slot_address, pose)
        self.memory.write(self.address + CONTROL_OFFSET, struct.pack("<I", slot_address))

    def release(self):
        self.memory.write(self.address + CONTROL_OFFSET, bytes(4))
        if self.head_visibility is not None:
            self.head_visibility.show(force=True)


@contextmanager
def installed(kernel, pid, base, head_visibility=None, recovery=None):
    memory = GameMemory(kernel, pid)
    address = None
    patched = False
    site = base + PUBLISH_RVA
    try:
        address = memory.allocate_memory(memory.handle, None, 2 * PAGE_SIZE, 0x3000, 0x04)
        if not address:
            raise ct.WinError(ct.get_last_error())
        head_control = head_visibility.address + PAGE_SIZE if head_visibility is not None else 0
        code = trampoline(address, base, head_control)
        camera = Camera(memory, address, head_visibility)
        memory.write(address, code)
        memory.protect(address, PAGE_SIZE, 0x20)
        if not memory.flush(memory.handle, address, len(code)):
            raise ct.WinError(ct.get_last_error())
        call = relative_call(site, address)
        if recovery:
            recovery.zero(address + CONTROL_OFFSET)
            recovery.patch(site, PUBLISH, call)
        memory.patch(site, PUBLISH, call, kernel)
        patched = True
        try:
            yield camera
        finally:
            if not memory.exited():
                try:
                    camera.release()
                finally:
                    memory.patch(site, call, PUBLISH, kernel)
    finally:
        # A game thread could still be exiting the trampoline after restoring the call.
        if address and not patched:
            current = read(kernel, memory.handle, site, len(PUBLISH))
            if current == PUBLISH:
                memory.free_memory(memory.handle, address, 0, 0x8000)
        memory.close(memory.handle)


def camera_buffer(kernel, handle, base):
    raw = read(kernel, handle, base + CAMERA_RVA - 8, 8 + 2 * CAMERA_SIZE)
    if raw is None:
        raise RuntimeError("Cannot read the game camera")
    index = u32(raw, 4)
    if index not in (0, 1):
        raise RuntimeError("Unexpected camera buffer index")
    slot = 8 + index * CAMERA_SIZE
    if u32(raw, slot) != base + CAMERA_VTABLE_RVA:
        raise RuntimeError("Unexpected camera object")
    return raw[slot:slot + CAMERA_SIZE]


def game_pose(buffer):
    eye = struct.unpack_from("<3f", buffer, POSE_OFFSET)
    aim = struct.unpack_from("<3f", buffer, POSE_OFFSET + 16)
    roll, = struct.unpack_from("<f", buffer, POSE_OFFSET + 48)
    forward = tuple(target - origin for origin, target in zip(eye, aim))
    distance = math.hypot(*forward)
    if not all(math.isfinite(value) for value in (*eye, *forward, roll)) or distance < 0.01:
        raise RuntimeError("Camera has no usable position or direction")
    yaw, pitch = look_angles(forward)
    return eye, yaw, pitch, distance, roll


def expected_view(eye, yaw, pitch, roll):
    forward, up = direction(yaw, pitch)
    right = (-math.cos(yaw), 0, math.sin(yaw))
    sine, cosine = math.sin(roll), math.cos(roll)
    rolled_right = tuple(cosine * r - sine * u for r, u in zip(right, up))
    rolled_up = tuple(sine * r + cosine * u for r, u in zip(right, up))
    basis = (rolled_right, rolled_up, forward)
    return tuple(value for row in zip(*basis) for value in (*row, 0)) + (
        *(-sum(a * b for a, b in zip(eye, axis)) for axis in basis), 1,
    )


def diagnose(kernel, handle, base, camera, seconds, rotation_only, orbit_only,
             first_person_only):
    if rotation_only:
        print("Starting the rotation test in 5 seconds.", flush=True)
        time.sleep(5)
    eye, yaw, pitch, distance, roll = game_pose(camera_buffer(kernel, handle, base))
    translations = (
        ("world X", (0.9, 0, 0), yaw, pitch, roll),
        ("world Y", (0, 0.65, 0), yaw, pitch, roll),
        ("world Z", (0, 0, 0.9), yaw, pitch, roll),
    )
    rotations = (
        ("yaw 90 deg", (0, 0, 0), yaw + math.pi / 2, pitch, roll),
        ("pitch 45 deg", (0, 0, 0), yaw, math.pi / 4, roll),
        ("pitch 120 deg", (0, 0, 0), yaw, 2 * math.pi / 3, roll),
        ("roll 30 deg", (0, 0, 0), yaw, pitch, roll + math.pi / 6),
    )
    if orbit_only or first_person_only:
        pivots = fighter_pivots(kernel, handle, base)
        if pivots is None:
            raise RuntimeError("Cannot locate the two fighters in the active match")
        cases = []
    if first_person_only:
        eyes = head_eyes(kernel, handle, base, pivots)
        for player in range(2):
            height = estimated_eye_height(kernel, handle, base, player)
            target, view_yaw, view_pitch, radius, head_roll = FirstPerson(player, yaw).view(
                pivots, height, eyes)
            source = "animated head" if eyes[player] is not None else "root estimate"
            cases.append((f"P{player + 1} first person ({source})",
                          target, view_yaw, view_pitch, head_roll, radius))
    elif orbit_only:
        for player, pivot in enumerate(pivots):
            orbit = Orbit.from_view(player, pivot, eye, yaw, pitch)
            orbit.transition = 0
            for turn in (0, math.pi / 2):
                orbit.yaw += turn
                target, view_yaw, view_pitch, radius = orbit.view(pivot)
                aim = struct.unpack_from("<3f", camera_payload(target, view_yaw, view_pitch,
                                                                radius, roll), 16)
                if math.dist(aim, pivot) > 0.001:
                    raise RuntimeError("Orbit camera is not aimed at the fighter")
                cases.append((f"P{player + 1} orbit {round(math.degrees(turn))} deg",
                              target, view_yaw, view_pitch, roll, radius))
    else:
        angles = rotations if rotation_only else translations + rotations
        cases = [(label, tuple(a + b for a, b in zip(eye, delta)), y, p, r, distance)
                 for label, delta, y, p, r in angles]
    for label, target, test_yaw, test_pitch, test_roll, test_distance in cases:
        near = FIRST_PERSON_NEAR if first_person_only else 0.0
        fov = FIRST_PERSON_FOV if first_person_only else 0.0
        camera.publish(camera_payload(target, test_yaw, test_pitch, test_distance, test_roll, near, fov))
        time.sleep(seconds / 2)
        first = camera_buffer(kernel, handle, base)
        first_hits = u32(read(kernel, handle, camera.address + HITS_OFFSET, 4), 0)
        # There are no controller writes between the samples, as on key release.
        time.sleep(seconds / 2)
        last = camera_buffer(kernel, handle, base)
        hits = u32(read(kernel, handle, camera.address + HITS_OFFSET, 4), 0)
        actual, *_ = game_pose(last)
        matrices = (struct.unpack_from("<16f", first, 4), struct.unpack_from("<16f", last, 4))
        expected = expected_view(target, test_yaw, test_pitch, test_roll)
        error = max(abs(a - b) for matrix in matrices for a, b in zip(matrix, expected))
        if first_person_only:
            for buffer in (first, last):
                clip_near, = struct.unpack_from("<f", buffer, 0xBC)
                if not math.isclose(clip_near, near, abs_tol=0.0001):
                    raise RuntimeError("The first-person near plane did not reach the game camera")
        print(f"{label}: eye {actual}, view matrix error {error:.6f}, "
              f"frames without new input {hits - first_hits}",
              flush=True)
        if math.dist(actual, target) > 0.01 or not error <= 0.01 or hits == first_hits:
            print("Expected matrix:", tuple(round(value, 5) for value in expected))
            print("Actual matrix:  ", tuple(round(value, 5) for value in matrices[-1]))
            raise RuntimeError("The published camera pose did not reach the game view matrix")


def control(kernel, handle, base, camera, pid, start_first_person=None, status_file=None):
    user32 = ct.WinDLL("user32")
    foreground = bind(user32, "GetForegroundWindow", wt.HWND)
    window_pid = bind(user32, "GetWindowThreadProcessId", wt.DWORD, wt.HWND, ct.POINTER(wt.DWORD))
    key_state = bind(user32, "GetAsyncKeyState", ct.c_short, ct.c_int)

    def held(key):
        return bool(key_state(key) & 0x8000)

    def down(key):
        if not in_game:
            return False
        pressed = held(key)
        if not pressed:
            held_on_return.discard(key)
        return pressed and key not in held_on_return

    print("Top row: Alt+- enable  |  Alt+=/+ restore game camera")
    print("Num 8/2 forward/back, 4/6 left/right, 9/3 up/down")
    print("Num 7/1 yaw, +/- pitch, /* roll, Shift faster. Keep DOA5LR in offline Free Training.",
          flush=True)
    print("B cycles free flight / P1 orbit / P2 orbit. V toggles first person (Num 9/3 eye height).",
          flush=True)
    previous_enable = False
    previous_restore = False
    previous_orbit_key = False
    previous_first_person_key = False
    active = False
    orbit = None
    first_person = None
    eye_trim = [0.0, 0.0]
    previous_view = None
    last_pose = None
    in_game = False
    held_on_return = set()
    head_guard = HeadOverlapGuard(camera.head_visibility) if camera.head_visibility else None
    floor_guard = FloorGuard()
    next_status = 0.0
    if start_first_person is not None:
        eye, yaw, pitch, distance, roll = game_pose(camera_buffer(kernel, handle, base))
        previous_view = (eye, yaw, pitch, distance, roll)
        first_person = FirstPerson(start_first_person - 1, yaw)
        active = True
        roll = 0.0
        print(f'P{start_first_person} first person (remote start)', flush=True)
    camera_keys = (0x10, 0x12, 0x17, 0x42, 0x56, *range(0x61, 0x6A),
                   0x6A, 0x6B, 0x6D, 0x6F, 0xBB, 0xBD)
    previous = time.monotonic()
    while not camera.memory.exited():
        time.sleep(1 / 90)
        now = time.monotonic()
        dt, previous = min(now - previous, 0.05), now
        owner = wt.DWORD()
        window_pid(foreground(), ct.byref(owner))
        game_has_focus = owner.value == pid
        if game_has_focus and not in_game:
            held_on_return = {key for key in camera_keys if held(key)}
        in_game = game_has_focus
        alt = down(0x12)
        top_minus = down(0xBD)
        top_plus = down(0xBB)
        # Accept an alternate key code for the top-row Alt+= shortcut.
        ime_plus = down(0x17)
        enable = alt and top_minus
        restore = alt and (top_plus or ime_plus)
        enable_pressed = enable and not previous_enable
        restore_pressed = restore and not previous_restore
        previous_enable, previous_restore = enable, restore
        orbit_key = in_game and down(0x42)
        switch_orbit = orbit_key and not previous_orbit_key
        previous_orbit_key = orbit_key
        first_person_key = in_game and down(0x56)
        switch_first_person = first_person_key and not previous_first_person_key
        previous_first_person_key = first_person_key
        if active and restore_pressed:
            camera.release()
            if head_guard:
                head_guard.reset()
            floor_guard.reset()
            active = False
            orbit = None
            first_person = None
            previous_view = None
            last_pose = None
        elif not active and enable_pressed and not restore:
            eye, yaw, pitch, distance, roll = game_pose(camera_buffer(kernel, handle, base))
            active = True
        if not active:
            continue
        needs_fighters = orbit or first_person or switch_orbit or switch_first_person
        pivots = fighter_pivots(kernel, handle, base) if needs_fighters else None
        if first_person is not None and (switch_first_person or pivots is None):
            eye, yaw, pitch, distance, roll = previous_view
            first_person = None
            previous_view = None
            print("First person off", flush=True)
        elif switch_first_person:
            if pivots is not None:
                previous_view = (eye, yaw, pitch, distance, roll)
                first_person = FirstPerson(orbit.player if orbit else 0, yaw)
                roll = 0.0
                print(f"P{first_person.player + 1} first person", flush=True)
            else:
                print("P1/P2 positions are unavailable. Enter an active offline match.", flush=True)
        if switch_orbit and first_person is not None:
            first_person = FirstPerson(1 - first_person.player, yaw)
            roll = 0.0
            print(f"P{first_person.player + 1} first person", flush=True)
        elif switch_orbit:
            player = orbit.player + 1 if orbit else 0
            if player == 2:
                orbit = None
                print("Free flight", flush=True)
            elif pivots is not None:
                orbit = Orbit.from_view(player, pivots[player], eye, yaw, pitch)
                print(f"Orbit P{player + 1}", flush=True)
            else:
                print("P1/P2 positions are unavailable. Enter an active offline match.", flush=True)
        if orbit is not None and pivots is None:
            orbit = None
            print("Fighter positions lost. Returning to free flight.", flush=True)
        turn = int(down(0x67)) - int(down(0x61))
        tilt = int(down(0x6B)) - int(down(0x6D))
        roll = math.remainder(roll + (int(down(0x6F)) - int(down(0x6A))) * dt, math.tau)
        lateral = int(down(0x66)) - int(down(0x64))
        longitudinal = int(down(0x68)) - int(down(0x62))
        vertical = int(down(0x69)) - int(down(0x63))
        speed = (5 if down(0x10) else 1.5) * dt
        view_roll = roll
        if first_person is not None:
            player = first_person.player
            height = estimated_eye_height(kernel, handle, base, player)
            adjustment = 0.8 if down(0x10) else 0.35
            height_with_trim = min(2.5, max(0.15, height + eye_trim[player] + vertical * dt * adjustment))
            eye_trim[player] = height_with_trim - height
            eyes = head_eyes(kernel, handle, base, pivots)
            throw_target = throw_gaze_target(kernel, handle, base, player, pivots)
            if throw_target is None:
                first_person.turn = math.remainder(first_person.turn + turn * dt, math.tau)
                first_person.pitch = math.remainder(first_person.pitch + tilt * dt, math.tau)
            eye, yaw, pitch, distance, head_roll = first_person.view(
                pivots, height, eyes, eye_trim[player])
            if throw_target is not None:
                delta = tuple(target - origin for target, origin in zip(throw_target, eye))
                target_distance = math.hypot(*delta)
                if target_distance >= 0.01:
                    yaw, pitch = look_angles(delta)
                    distance = target_distance
            if head_guard:
                original_eye = eye
                eye = head_guard.update(kernel, handle, base, player, eyes, eye,
                                        direction(yaw, pitch)[0], dt, now)
                distance += math.dist(original_eye, eye)
            before_floor = eye
            eye = floor_guard.update(kernel, handle, base + PLAYER_ANCHOR_RVA, pivots,
                                     player, eye, FIRST_PERSON_NEAR, FIRST_PERSON_FOV)
            if eye != before_floor and throw_target is not None:
                delta = tuple(target - origin for target, origin in zip(throw_target, eye))
                if math.hypot(*delta) >= .01:
                    yaw, pitch = look_angles(delta)
                    distance = math.hypot(*delta)
            view_roll += head_roll
        elif orbit is not None:
            orbit.yaw = math.remainder(orbit.yaw + (turn + lateral) * dt, math.tau)
            orbit.pitch = math.remainder(orbit.pitch + tilt * dt, math.tau)
            orbit.radius = max(0.15, orbit.radius - longitudinal * speed)
            orbit.height += vertical * speed
            eye, yaw, pitch, distance = orbit.view(pivots[orbit.player])
            orbit.transition = max(0.0, orbit.transition - dt)
        else:
            yaw = math.remainder(yaw + turn * dt, math.tau)
            pitch = math.remainder(pitch + tilt * dt, math.tau)
            forward, _ = direction(yaw, pitch)
            right = (-math.cos(yaw), 0, math.sin(yaw))
            eye = tuple(value + speed * (lateral * right[i] + longitudinal * forward[i]
                                         + (vertical if i == 1 else 0))
                        for i, value in enumerate(eye))
        near = FIRST_PERSON_NEAR if first_person is not None else 0.0
        fov = FIRST_PERSON_FOV if first_person is not None else 0.0
        if first_person is None and head_guard:
            head_guard.reset()
            floor_guard.reset()
        pose = (eye, yaw, pitch, distance, view_roll, near, fov)
        # The selected head table must be published even if a paused pose is unchanged.
        signature = (pose, camera.head_visibility.selected if camera.head_visibility else 0)
        if signature != last_pose:
            camera.publish(camera_payload(*pose))
            last_pose = signature
        if status_file is not None and now >= next_status:
            status = dict(pid=pid, base=base, active=active,
                          player=first_person.player + 1 if first_person else None,
                          eye=eye, near=near, fov_degrees=math.degrees(fov) if fov else None,
                          camera_hook=camera.address,
                          head_filter=camera.head_visibility.address if camera.head_visibility else None,
                          head_hidden=bool(head_guard and head_guard.applied),
                          clearance_shift=head_guard.shift if head_guard else 0,
                          floor_shift=floor_guard.correction,
                          head_draws_skipped=camera.head_visibility.skipped_draws(kernel)
                          if camera.head_visibility else None)
            temporary = status_file.with_suffix('.tmp')
            try:
                temporary.write_text(json.dumps(status, indent=2), encoding='utf-8')
                temporary.replace(status_file)
            except OSError:
                # A Windows reader can temporarily deny replacement. Diagnostic
                # output must never release a live camera or interrupt a match.
                pass
            next_status = now + 0.5


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pid", type=int)
    parser.add_argument("--offline-training", "--offline", action="store_true", required=True)
    parser.add_argument("--diagnose", type=float, metavar="SECONDS_PER_AXIS")
    parser.add_argument('--start-first-person', type=int, choices=(1, 2),
                        help='Start directly in P1/P2 first person without sending key input')
    parser.add_argument('--status-file', type=Path, help=argparse.SUPPRESS)
    diagnostics = parser.add_mutually_exclusive_group()
    diagnostics.add_argument("--rotation-only", action="store_true", help="Only test rotations")
    diagnostics.add_argument("--orbit-only", action="store_true", help="Only test the two fighter pivots")
    diagnostics.add_argument("--first-person-only", action="store_true",
                             help="Only test the two first-person views")
    args = parser.parse_args()
    if args.diagnose is not None and not 0.25 <= args.diagnose <= 10:
        parser.error("Use 0.25–10 seconds per axis")
    if (args.rotation_only or args.orbit_only or args.first_person_only) and args.diagnose is None:
        parser.error("Diagnostic mode selectors require --diagnose")
    if args.start_first_person and args.diagnose is not None:
        parser.error('Use remote first-person start or diagnostic mode, not both')
    with open_game(args.pid) as (kernel, handle, base, filename):
        with Path(filename).open("rb") as executable:
            digest = hashlib.file_digest(executable, "sha256").hexdigest()
        if digest != IMAGE_HASH:
            raise RuntimeError("This script requires the verified Steam 1.10C executable")
        # A just-closed controller's detached watcher may still be restoring it.
        deadline = time.monotonic() + 1.5
        while (read(kernel, handle, base + PUBLISH_RVA, len(PUBLISH)) != PUBLISH
               and time.monotonic() < deadline):
            time.sleep(.05)
        if read(kernel, handle, base + PUBLISH_RVA, len(PUBLISH)) != PUBLISH:
            raise RuntimeError("The camera call is already modified. Exit the other camera tool, "
                               "or restart DOA5LR if its hook is still installed.")
        if read(kernel, handle, base + COPY_RVA, len(COPY_HEAD)) != COPY_HEAD:
            raise RuntimeError("The game's camera copy routine differs from the verified code")
        game_pose(camera_buffer(kernel, handle, base))
        try:
            with RecoveryJournal(args.pid, base) as recovery:
                with installed_head_filter(kernel, args.pid, base, recovery=recovery) as head_visibility:
                    head_visibility.synchronized = True
                    with installed(kernel, args.pid, base, head_visibility, recovery) as camera:
                        if args.diagnose is None:
                            control(kernel, handle, base, camera, args.pid,
                                    args.start_first_person, args.status_file)
                        else:
                            diagnose(kernel, handle, base, camera, args.diagnose, args.rotation_only,
                                     args.orbit_only, args.first_person_only)
        except KeyboardInterrupt:
            pass
        except GameExited:
            print('The game process exited.', flush=True)
            return
        restored = read(kernel, handle, base + PUBLISH_RVA, len(PUBLISH))
        if restored is None:
            print("The game process exited.", flush=True)
            return
        if restored != PUBLISH:
            raise RuntimeError("Could not verify restoration of the original call")
        print("Original game camera call restored.", flush=True)


if __name__ == "__main__":
    main()
