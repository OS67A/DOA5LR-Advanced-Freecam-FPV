"""x86 guard: preserve shadow draws while filtering screen-view meshes."""

import struct

RENDERER_POINTER_RVA = 0xEF10F0
GET_VIEWPORT_SLOT = 48
MAIN_CHECKS_OFFSET = 16
OTHER_CHECKS_OFFSET = 20
QUERY_FAILURES_OFFSET = 24
MAIN_SIZE_OFFSET = 32
OTHER_SIZE_OFFSET = 40
ASPECT_OFFSET = 48


class Code:
    def __init__(self):
        self.data = bytearray()
        self.labels = {}
        self.fixups = []

    def add(self, data):
        self.data += data

    def label(self, name):
        self.labels[name] = len(self.data)

    def jump(self, opcode, label):
        self.data += opcode + bytes(4)
        self.fixups.append((len(self.data)-4, label))

    def finish(self):
        for offset, label in self.fixups:
            struct.pack_into('<i', self.data, offset, self.labels[label]-offset-4)
        return bytes(self.data)


def viewport_guard(address, data, renderer_pointer):
    """Return EAX=1 for screen viewports, 0 for shadow/unknown viewports.

    Calls GetViewport on the game's render thread; preserves flags, other
    registers and the entire x87/SSE state around the COM method.
    https://learn.microsoft.com/windows/win32/api/d3d9/nf-d3d9-idirect3ddevice9-getviewport
    """
    p = lambda value: struct.pack('<I', value)
    c = Code()
    c.add(bytes.fromhex('9C 60 8B EC 81 EC 30 02 00 00 83 E4 F0 0F AE 04 24'))
    c.add(b'\xa1' + p(renderer_pointer) + b'\x85\xc0')
    c.jump(b'\x0f\x84', 'failure')
    c.add(bytes.fromhex('8B 88 C4 00 00 00 85 C9'))
    c.jump(b'\x0f\x84', 'failure')
    # VP lives above the 512-byte FXSAVE area. COM calls use stack space below it.
    c.add(bytes.fromhex('8D 84 24 00 02 00 00 50 8B 11 51 FF 92 C0 00 00 00 85 C0'))
    c.jump(b'\x0f\x85', 'failure')
    c.add(bytes.fromhex('8B 84 24 08 02 00 00 8B 94 24 0C 02 00 00 85 C0'))
    c.jump(b'\x0f\x84', 'failure')
    c.add(b'\x85\xd2')
    c.jump(b'\x0f\x84', 'failure')
    c.add(b'\xa3'+p(data+56)+b'\x89\x15'+p(data+60))
    # The live renderer uses 1920x2160 for the 16:9 screen, but 4096x4096
    # for shadows. Accept the screen aspect and its vertically doubled
    # layout, with 1.2% rounding/scaling tolerance. Preserve square maps.
    c.add(bytes.fromhex('8B F8 8B F2 69 C0 E8 03 00 00'))
    c.add(b'\x0f\xaf\x15' + p(data + ASPECT_OFFSET))
    c.add(bytes.fromhex('2B C2 99 33 C2 2B C2 6B CE 0C 3B C1'))
    c.jump(b'\x0f\x86', 'main')
    c.add(bytes.fromhex('69 C7 D0 07 00 00 8B D6'))
    c.add(b'\x0f\xaf\x15' + p(data + ASPECT_OFFSET))
    c.add(bytes.fromhex('2B C2 99 33 C2 2B C2 6B CE 0C 3B C1'))
    c.jump(b'\x0f\x87', 'other')
    c.label('main')
    c.add(b'\x89\x3d' + p(data + MAIN_SIZE_OFFSET))
    c.add(b'\x89\x35' + p(data + MAIN_SIZE_OFFSET + 4))
    c.add(b'\xf0\xff\x05' + p(data + MAIN_CHECKS_OFFSET))
    c.add(b'\xb8' + p(1))
    c.jump(b'\xe9', 'return')
    c.label('failure')
    c.add(b'\xf0\xff\x05' + p(data + QUERY_FAILURES_OFFSET))
    c.add(b'\x33\xc0')
    c.jump(b'\xe9', 'return')
    c.label('other')
    c.add(b'\x89\x3d' + p(data + OTHER_SIZE_OFFSET))
    c.add(b'\x89\x35' + p(data + OTHER_SIZE_OFFSET + 4))
    c.add(b'\xf0\xff\x05' + p(data + OTHER_CHECKS_OFFSET))
    c.add(b'\x33\xc0')
    c.label('return')
    # Saved EAX in PUSHAD is at EBP+28; restore all other CPU/FPU state.
    c.add(bytes.fromhex('89 45 1C 0F AE 0C 24 8B E5 61 9D C3'))
    return c.finish()
