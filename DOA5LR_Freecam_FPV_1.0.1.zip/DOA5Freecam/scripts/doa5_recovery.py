"""Recovery for the DLL edition. Contains no external process launcher."""
import os
from doa5_process import native_helper

class RecoveryJournal:
    def __init__(self, pid, base):
        self.native = native_helper()
        if self.native is None or pid != os.getpid():
            raise RuntimeError('The installed mod requires its in-game DLL host')

    def __enter__(self):
        return self

    def patch(self, site, old, new):
        if not self.native.FC_RegisterPatch(site, old, new, len(old)):
            raise RuntimeError('Could not register patch recovery')

    def zero(self, address):
        if not self.native.FC_RegisterZero(address):
            raise RuntimeError('Could not register camera release')

    def __exit__(self, *exception):
        if not self.native.FC_RestoreAll():
            raise RuntimeError('Native recovery could not restore the camera')
