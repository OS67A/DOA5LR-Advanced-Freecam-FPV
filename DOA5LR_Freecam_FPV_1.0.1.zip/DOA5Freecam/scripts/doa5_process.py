"""Small, standard-library-only process interface used by the shipped mod."""
import ctypes as ct
from ctypes import wintypes as wt
from contextlib import contextmanager
from pathlib import PureWindowsPath
import struct

_native = None

def use_native_helper(path):
    global _native
    _native = ct.WinDLL(str(path))
    for name, arguments in (
        ('FC_Patch', (ct.c_void_p, ct.c_void_p, ct.c_void_p, wt.DWORD)),
        ('FC_RegisterPatch', (ct.c_void_p, ct.c_void_p, ct.c_void_p, wt.DWORD)),
        ('FC_RegisterZero', (ct.c_void_p,)), ('FC_RestoreAll', ())):
        bind(_native, name, wt.BOOL, *arguments)
    return _native

def native_helper():
    return _native

PLAYER_ANCHOR = bytes.fromhex('AF 47 E9 42')
FIELDS = {
    'p1_character': (0x268F4, 'B'), 'p2_character': (0x26924, 'B'),
    'p1_move_type': (0x268FE, 'B'), 'p2_move_type': (0x2692E, 'B'),
    'p1_airborne': (0x35EF8, 'B'), 'p2_airborne': (0x36380, 'B'),
    'p1_x': (0x37594, 'f'), 'p2_x': (0x37C5C, 'f'),
}

def bind(library, name, result, *args):
    function = getattr(library, name)
    function.restype, function.argtypes = result, args
    return function

def read(kernel, handle, address, size):
    if not 0 < size <= 64 * 1024**2 or not 0 < address < 2**32:
        return None
    reader = bind(kernel, 'ReadProcessMemory', wt.BOOL, wt.HANDLE, ct.c_void_p,
                  ct.c_void_p, ct.c_size_t, ct.POINTER(ct.c_size_t))
    data = ct.create_string_buffer(size)
    got = ct.c_size_t()
    if reader(handle, address, data, size, ct.byref(got)) and got.value == size:
        return data.raw
    return None

def u32(data, offset=0):
    return struct.unpack_from('<I', data, offset)[0]

@contextmanager
def open_game(pid):
    kernel = ct.WinDLL('kernel32', use_last_error=True)
    opener = bind(kernel, 'OpenProcess', wt.HANDLE, wt.DWORD, wt.BOOL, wt.DWORD)
    close = bind(kernel, 'CloseHandle', wt.BOOL, wt.HANDLE)
    query = bind(kernel, 'QueryFullProcessImageNameW', wt.BOOL, wt.HANDLE, wt.DWORD,
                 wt.LPWSTR, ct.POINTER(wt.DWORD))
    modules = bind(kernel, 'K32EnumProcessModulesEx', wt.BOOL, wt.HANDLE,
                   ct.POINTER(wt.HMODULE), wt.DWORD, ct.POINTER(wt.DWORD), wt.DWORD)
    handle = opener(0x0400 | 0x0010 | 0x100000, False, pid)
    if not handle:
        raise ct.WinError(ct.get_last_error())
    try:
        filename = ct.create_unicode_buffer(32768)
        length = wt.DWORD(len(filename))
        if not query(handle, 0, filename, ct.byref(length)):
            raise ct.WinError(ct.get_last_error())
        if PureWindowsPath(filename.value).name.lower() != 'game.exe':
            raise ValueError('The target is not DOA5LR game.exe')
        module, needed = wt.HMODULE(), wt.DWORD()
        if not modules(handle, ct.byref(module), ct.sizeof(module), ct.byref(needed), 1):
            raise ct.WinError(ct.get_last_error())
        yield kernel, handle, module.value, filename.value
    finally:
        close(handle)
