"""POV near-plane clearance above the fighters' observed local ground level."""

import math

from doa5_process import read, FIELDS


def near_plane_clearance(near, fov, aspect):
    # A sphere containing all near-plane corners stays above a horizontal floor
    # regardless of camera pitch/roll, including the wider first-person FOV.
    tangent = math.tan(fov / 2)
    return near * math.sqrt(1 + tangent*tangent*(1 + aspect*aspect)) + .003


class FloorGuard:
    def __init__(self):
        self.levels = [None, None]
        self.last_roots = None
        self.correction = 0.0

    def reset(self):
        self.levels = [None, None]
        self.last_roots = None
        self.correction = 0.0

    def correct(self, pivots, player, eye, grounded_idle, airborne, near, fov, aspect=16/9):
        roots = tuple((x, y - .9, z) for x, y, z in pivots)
        if self.last_roots and any(math.dist(a, b) > 10 for a, b in zip(roots, self.last_roots)):
            self.reset()
        self.last_roots = roots
        for p in (0, 1):
            if grounded_idle[p]:
                self.levels[p] = roots[p][1]
        floor = self.levels[player]
        if floor is None and not any(airborne) and abs(roots[0][1] - roots[1][1]) < .05:
            floor = min(r[1] for r in roots)
        # A drop through a stage floor invalidates the old platform height.
        if floor is not None and roots[player][1] < floor - .2:
            self.levels[player] = floor = None
        self.correction = 0.0
        if floor is not None:
            minimum = floor + near_plane_clearance(near, fov, aspect)
            self.correction = max(0., minimum - eye[1])
        return eye[0], eye[1] + self.correction, eye[2]

    def update(self, kernel, handle, anchor, pivots, player, eye, near, fov, aspect=16/9):
        airborne, idle = [], []
        for p in (1, 2):
            air = read(kernel, handle, anchor + FIELDS[f'p{p}_airborne'][0], 1)
            move = read(kernel, handle, anchor + FIELDS[f'p{p}_move_type'][0], 1)
            airborne.append(air != b'\x00')
            idle.append(air == b'\x00' and move == b'\x00')
        return self.correct(pivots, player, eye, idle, airborne, near, fov, aspect)
