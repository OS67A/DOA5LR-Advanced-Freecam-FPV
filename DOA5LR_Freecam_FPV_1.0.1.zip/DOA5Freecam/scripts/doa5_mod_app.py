"""Game-hosted entry point: no subprocess or external Python installation."""
from pathlib import Path
import hashlib
import json
import os
import sys
import time
import traceback

def run():
    root = Path(__file__).resolve().parent.parent
    logdir = Path(os.environ.get('LOCALAPPDATA', str(root))) / 'DOA5LRFreecam'
    logdir.mkdir(parents=True, exist_ok=True)
    log = (logdir/f'freecam-{os.getpid()}.log').open('w', encoding='utf-8', buffering=1)
    sys.stdout = sys.stderr = log
    print('DOA5LR Freecam 1.0.1 - DLL host, no external process')
    print('Package:', root)
    from doa5_process import open_game, use_native_helper, read
    helper = use_native_helper(root.parent/'winmm.dll')
    import doa5_freecam as freecam
    try:
        with open_game(os.getpid()) as (kernel, handle, base, filename):
            if Path(filename).resolve().parent != root.parent:
                raise RuntimeError('The host must be beside this package')
            if hashlib.sha256(Path(filename).read_bytes()).hexdigest() != freecam.IMAGE_HASH:
                raise RuntimeError('This release supports the verified Steam DOA5LR 1.10C executable only')
            print('Waiting for the match camera. Enter offline Free Training.')
            while True:
                try:
                    freecam.game_pose(freecam.camera_buffer(kernel, handle, base))
                    if freecam.fighter_pivots(kernel, handle, base) is not None:
                        break
                except RuntimeError:
                    pass
                if (root/'disabled.flag').exists():
                    print('Disabled by flag file'); return
                time.sleep(.25)
        sys.argv = [str(root/'scripts/doa5_freecam.py'), str(os.getpid()), '--offline-training',
                    '--status-file', str(logdir/f'status-{os.getpid()}.json')]
        freecam.main()
        print('Camera controller finished.')
    except BaseException:
        traceback.print_exc()
    finally:
        helper.FC_RestoreAll()
        print('Controller finished; native recovery remains in the game.')
        log.flush()
