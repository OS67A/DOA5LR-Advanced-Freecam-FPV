"""Filter POV hair and face interiors at individual color-pass mesh draws."""

from contextlib import contextmanager
import ctypes as ct
import hashlib
import math
import struct
import time

from doa5_process import read
from doa5_render_pass import Code, viewport_guard, RENDERER_POINTER_RVA, ASPECT_OFFSET

PAGE_SIZE = 4096
UNIFIED_SITE = 0x9BC978

# Retained only for recovery/inspection of older whole-model filter journals.
DRAW_METHODS = (
    (0x9BD334, 0x3A5D50), (0x9BD59C, 0x3A5E90),
    (0x9BD1D4, 0x3A6000), (0x9BD544, 0x3A6140),
    (0x9BCFA4, 0x3A6000), (0x9BD01C, 0x3A5D50),
    (0x9BD22C, 0x3A6140), (0x9BD4EC, 0x3A5E90),
    # Rigid/matrix counterparts also cover unskinned face parts and accessories.
    (0x9BD360, 0x3A5DE0), (0x9BD5C8, 0x3A5F40),
    (0x9BD200, 0x3A6090), (0x9BD570, 0x3A61F0),
    (0x9BCFD0, 0x3A6090), (0x9BD048, 0x3A5DE0),
    (0x9BD258, 0x3A61F0), (0x9BD518, 0x3A5F40),
    # Opaque skin/face parts use a distinct material path, with metadata at +34.
    (UNIFIED_SITE, 0x38E6F0),
)
BANK_RVA = 0x2053FA8
BANK_VTABLE_RVA = 0xBBB4E0
HEAD_RADII = (0.105, 0.145, 0.115)
OVERLAP_ENTER_MARGIN = 0.035
OVERLAP_LEAVE_MARGIN = 0.09
OVERLAP_RELEASE_SECONDS = 0.12
PRIMITIVE_DRAW_RVA = 0x7E3480
# Include rigid/skinned hair and eyelash paths. The viewport guard, rather
# than the caller name, preserves the square shadow-map draws.
COLOR_CALLS = (0x38C3B9, 0x38C4E6, 0x38C53E, 0x38C639, 0x38C691,
               0x38C773, 0x38C7E0, 0x38C8ED, 0x38C96E, 0x3971EB, 0x39725F,
               0x3984A8, 0x3985BF, 0x398AE9, 0x398BD0,
               0x387E37, 0x387EC2, 0x39DF3F, 0x39E1A8, 0x39E42D,
               0x39E6A6, 0x39E943, 0x39EBE7, 0x39EEA0, 0x39F14A,
               0x39F441, 0x39F742, 0x39FA58, 0x39FD59,
               0x441765, 0x456BB5, 0x7C48CA, 0x7C4A5F)
PREPASS_CALLS = (0x3981F1, 0x3982AE, 0x398393, 0x398861, 0x39891E,
                 0x398A03, 0x3A087F, 0x3A096A, 0x3A0A7C)
PREPASS_DRAW_RVA = 0x7E34A0
INTERIOR_CACHE = {}


def filter_patch_specs(base):
    for rva in COLOR_CALLS:
        yield base + rva, b'\xe8' + struct.pack('<i', PRIMITIVE_DRAW_RVA - rva - 5)
    for rva in PREPASS_CALLS:
        yield base + rva, b'\xe8' + struct.pack('<i', PREPASS_DRAW_RVA - rva - 5)
    yield base + UNIFIED_SITE, struct.pack('<I', base + 0x38E6F0)


def interior_kind(mesh):
    names = set(mesh.get('weighted_names', ()))
    if not names or not mesh.get('vertices'):
        return None
    eye_bones = {name for name in names if name.startswith('OPT_Face_')
                 and (name.endswith('_eye') or name.endswith('_eyelid'))}
    if eye_bones and names <= eye_bones | {'MOT01_Head'}:
        return 'eyes'
    if any('tongue' in name.lower() for name in names) and all(
            'tongue' in name.lower() or name in ('OPT_Face_jaw', 'MOT01_Head') for name in names):
        return 'tongue'
    bounds = mesh.get('local_bounds')
    if ('face' in mesh.get('group', '').lower() and names <= {'MOT01_Head', 'OPT_Face_jaw'}
            and bounds and all(b-a <= limit for a, b, limit in zip(bounds[0], bounds[1], (.14, .09, .13)))):
        return 'teeth'
    return None


def model_interiors(data, hair=False, surface=False):
    from doa5_tmc_parts import Chunk, text, rig, meshes
    root = Chunk(data, 0)
    chunks = {text(data, at, 8): Chunk(data, at) for at in root.entries
              if at and struct.unpack_from('<I', data, at + 8)[0] == 0x01010000}
    nodes, palettes = rig(data, chunks)
    result = []
    for mesh in meshes(data, chunks, nodes, palettes):
        if hair:
            name = mesh['group'].lower()
            kind = 'hair' if mesh.get('vertices') and ('hair' in name or 'zdmodel' in name) else None
        elif surface:
            name = mesh['group'].lower()
            kind = 'surface' if mesh.get('vertices') and 'face' in name and interior_kind(mesh) is None else None
        else:
            kind = interior_kind(mesh)
        if kind is None:
            continue
        group = Chunk(data, chunks['MdlGeo'].entries[mesh['group_id']])
        offset = group.entries[mesh['part']]
        result.append(dict(offset=offset, kind=kind, group=mesh['group'], part=mesh['part']))
    return tuple(result)


def loaded_model_part_ranges(kernel, handle, base, player, hair=False, surface=False):
    if player not in (0, 1):
        return ()
    bank = read(kernel, handle, base + BANK_RVA + player * 0x50, 0x40)
    if bank is None or struct.unpack_from('<I', bank)[0] != base + BANK_VTABLE_RVA:
        return ()
    sentinel, count = struct.unpack_from('<II', bank, 0x34)
    if not 0 < count <= 128:
        return ()
    first = read(kernel, handle, sentinel, 4)
    if first is None:
        return ()
    current, = struct.unpack('<I', first)
    ranges, seen = set(), set()
    for _ in range(count):
        if current == sentinel or current in seen:
            break
        seen.add(current)
        node = read(kernel, handle, current, 32)
        if node is None:
            return ()
        following, _, _, kind, size, resource, _, _ = struct.unpack('<8I', node)
        kinds = (0x11, 0x13, 0x19) if hair else (0x13, 0x19)
        if kind in kinds and 0x100 <= size <= 64*1024**2:
            prefix = read(kernel, handle, resource, min(size, 4096))
            if prefix and prefix[:4] == b'TMC\x00':
                key = (resource, size, hair, surface, bank[0x18:0x20], hashlib.sha256(prefix).digest())
                if key not in INTERIOR_CACHE:
                    data = read(kernel, handle, resource, size)
                    if data is not None:
                        try:
                            parts = model_interiors(data, hair=hair, surface=surface)
                        except (ValueError, KeyError, IndexError, struct.error):
                            parts = ()
                        if len(INTERIOR_CACHE) >= 64:
                            INTERIOR_CACHE.clear()
                        INTERIOR_CACHE[key] = parts
                for part in INTERIOR_CACHE.get(key, ()):
                    ranges.add((resource + part['offset'], resource + part['offset'] + 1))
        current = following
    return tuple(sorted(ranges))


def loaded_interior_ranges(kernel, handle, base, player):
    return loaded_model_part_ranges(kernel, handle, base, player)


def loaded_hair_ranges(kernel, handle, base, player):
    return loaded_model_part_ranges(kernel, handle, base, player, hair=True)


def loaded_face_surface_ranges(kernel, handle, base, player):
    return loaded_model_part_ranges(kernel, handle, base, player, surface=True)


def head_volume(animated_eye):
    eye, axes = animated_eye
    center = tuple(p + 0.025 * up - 0.04 * forward
                   for p, up, forward in zip(eye, axes[1], axes[2]))
    return center, axes


def inside_own_head(eye, volume):
    center, axes = volume
    relative = tuple(a - b for a, b in zip(eye, center))
    return sum((sum(a*b for a, b in zip(relative, axis)) / (r + 0.01))**2
               for axis, r in zip(axes, HEAD_RADII)) <= 1.0


def head_separation(first, second):
    """Signed gap between head ellipsoid supports along their center line."""
    center, axes = first
    other, other_axes = second
    delta = tuple(b - a for a, b in zip(center, other))
    distance = math.hypot(*delta)
    if distance < 1e-8:
        return -2 * max(HEAD_RADII)
    line = tuple(value / distance for value in delta)
    supports = [math.sqrt(sum((r * sum(a * b for a, b in zip(axis, line)))**2
                             for r, axis in zip(HEAD_RADII, basis)))
                for basis in (axes, other_axes)]
    return distance - sum(supports)


class HeadOverlapGuard:
    """Suppress own head interiors in POV without moving backwards on overlap."""

    def __init__(self, visibility):
        self.visibility = visibility
        self.player = None
        self.hidden = False
        self.overlapping = False
        self.separated_at = None
        self.shift = 0.0
        self.ranges = ()
        self.opponent_ranges = ()
        self.hair_ranges = ()
        self.surface_ranges = self.opponent_surface_ranges = ()
        self.refresh_at = 0.0
        self.applied = ()

    def reset(self):
        if self.applied:
            self.visibility.show()
        self.player = None
        self.hidden = False
        self.overlapping = False
        self.separated_at = None
        self.shift = 0.0
        self.ranges = self.applied = ()
        self.opponent_ranges = ()
        self.hair_ranges = ()
        self.surface_ranges = self.opponent_surface_ranges = ()
        self.refresh_at = 0.0

    def update(self, kernel, handle, base, player, eyes, eye, forward, dt, now=None):
        now = time.monotonic() if now is None else now
        if self.player != player:
            self.reset()
            self.player = player
        if eyes[player] is None or eyes[1 - player] is None:
            self.reset()
            return eye
        own, other = map(head_volume, (eyes[player], eyes[1 - player]))
        gap = head_separation(own, other)
        if gap < OVERLAP_ENTER_MARGIN:
            self.overlapping = True
            self.separated_at = None
        elif gap > OVERLAP_LEAVE_MARGIN:
            if self.separated_at is None:
                self.separated_at = now
            elif now - self.separated_at >= OVERLAP_RELEASE_SECONDS:
                self.overlapping = False
        else:
            self.separated_at = None
        # A camera inside its own face can see teeth, eyeballs and hair even
        # without contact with the opponent. Cover that independent condition.
        self.hidden = self.overlapping or inside_own_head(eye, own)
        opponent_inside = self.overlapping or inside_own_head(eye, other)
        if now >= self.refresh_at:
            self.ranges = loaded_interior_ranges(kernel, handle, base, player)
            self.hair_ranges = loaded_hair_ranges(kernel, handle, base, player)
            self.opponent_ranges = loaded_interior_ranges(kernel, handle, base, 1-player)
            self.surface_ranges = loaded_face_surface_ranges(kernel, handle, base, player)
            self.opponent_surface_ranges = loaded_face_surface_ranges(kernel, handle, base, 1-player)
            self.refresh_at = now + 0.25
        wanted = self.hair_ranges + (self.ranges if self.hidden else ())
        if opponent_inside:
            wanted += self.opponent_ranges
        # The camera must actually be inside the head before removing its skin
        # surface; head proximity alone must not make the opponent's face vanish.
        if inside_own_head(eye, own):
            wanted += self.surface_ranges
        if inside_own_head(eye, other):
            wanted += self.opponent_surface_ranges
        wanted = tuple(sorted(set(wanted)))
        if wanted != self.applied:
            if wanted:
                self.visibility.hide_ranges(wanted)
            else:
                self.visibility.show()
            self.applied = wanted
            print(f'P{player + 1} POV interiors {"hidden" if wanted else "restored"}', flush=True)
        # Retraction exposed the inside of the owner's skull and detached the
        # view from the eyes. Overlap must never trigger that displacement.
        self.shift = 0.0
        return eye


def loaded_head_ranges(kernel, handle, base, player):
    if player not in (0, 1):
        return ()
    bank = read(kernel, handle, base + BANK_RVA + player * 0x50, 0x40)
    if bank is None or struct.unpack_from('<I', bank)[0] != base + BANK_VTABLE_RVA:
        return ()
    sentinel, count = struct.unpack_from('<II', bank, 0x34)
    if not 0 < count <= 128:
        return ()
    node = read(kernel, handle, sentinel, 8)
    if node is None:
        return ()
    current, = struct.unpack_from('<I', node)
    result, visited = [], set()
    for _ in range(count):
        if current == sentinel or current in visited:
            break
        visited.add(current)
        node = read(kernel, handle, current, 0x20)
        if node is None:
            return ()
        following, _, _, kind, size, resource, _, _ = struct.unpack('<8I', node)
        if kind in (0x11, 0x13) and 0x100 <= size <= 64 * 1024**2:
            header = read(kernel, handle, resource, 4)
            if header == b'TMC\x00':
                result.append((resource, resource + size))
        current = following
    return tuple(result) if len(result) == 2 else ()


def draw_filter_stub(address, control, hits, target, pointer_offset=4, stack_pop=4, pass_guard=0):
    p = lambda value: struct.pack('<I', value)
    code = bytearray(b'\x9c\x50\x52\x56')  # preserve flags/eax/edx/esi
    code += (b'\x8b\xd1\x90' if pointer_offset is None else b'\x8b\x51' + bytes((pointer_offset,)))
    code += b'\x8b\x35' + p(control)
    code += b'\x85\xf6\x74\x00'
    null_branch = len(code) - 1
    code += b'\x8b\x06\x83\xc6\x04\x85\xc0\x74\x00'
    empty_branch = len(code) - 1
    loop = len(code)
    code += b'\x3b\x16\x72\x05\x3b\x56\x04\x72\x00'
    match_branch = len(code) - 1
    code += b'\x83\xc6\x08\x48\x75\x00'
    code[-1] = (loop - len(code)) & 0xff
    original = len(code)
    code[null_branch] = original - null_branch - 1
    code[empty_branch] = original - empty_branch - 1
    code += b'\x5e\x5a\x58\x9d\xe9'
    code += struct.pack('<i', target - (address + len(code) + 4))
    code[match_branch] = len(code) - match_branch - 1
    if pass_guard:
        code += b'\xe8' + struct.pack('<i', pass_guard-(address+len(code)+5))
        code += b'\x85\xc0\x0f\x84' + struct.pack('<i', original-(len(code)+8))
    code += b'\xf0\xff\x05' + p(hits) + b'\x5e\x5a\x58\x9d'
    code += b'\xc2' + struct.pack('<H', stack_pop) if stack_pop else b'\xc3'
    return bytes(code)


def unified_filter_stub(address, control, hits, target, pass_guard=0):
    """Hide selected drawable parts; empty parts do not invalidate the batch."""
    p = lambda value: struct.pack('<I', value)
    c = Code()
    c.add(b'\x9c\x60\x8b\x59\x2c\x85\xdb')
    c.jump(b'\x0f\x84', 'pass')
    c.add(b'\x81\xfb'+p(128))
    c.jump(b'\x0f\x87', 'pass')
    c.add(b'\x8b\x2d'+p(control)+b'\x85\xed')
    c.jump(b'\x0f\x84', 'pass')
    c.add(b'\x8d\x79\x34\x33\xc9')
    c.label('outer')
    c.add(b'\x8b\x17\x85\xd2')
    c.jump(b'\x0f\x84', 'next_part')
    c.add(b'\x83\x7a\x74\x00')
    c.jump(b'\x0f\x84', 'next_part')
    c.add(b'\x83\x7a\x7c\x00')
    c.jump(b'\x0f\x84', 'next_part')
    c.add(b'\x8b\x45\x00\x8d\x75\x04\x85\xc0')
    c.jump(b'\x0f\x84', 'pass')
    c.label('inner')
    c.add(b'\x3b\x16')
    c.jump(b'\x0f\x82', 'next_range')
    c.add(b'\x3b\x56\x04')
    c.jump(b'\x0f\x82', 'matched')
    c.label('next_range')
    c.add(b'\x83\xc6\x08\x48')
    c.jump(b'\x0f\x85', 'inner')
    c.jump(b'\xe9', 'pass')
    c.label('matched')
    c.add(b'\x41')
    c.label('next_part')
    c.add(b'\x83\xc7\x04\x4b')
    c.jump(b'\x0f\x85', 'outer')
    c.add(b'\x85\xc9')
    c.jump(b'\x0f\x84', 'pass')
    if pass_guard:
        c.add(b'\xe8'+struct.pack('<i',pass_guard-(address+len(c.data)+5))+b'\x85\xc0')
        c.jump(b'\x0f\x84', 'pass')
    c.add(b'\xf0\xff\x05'+p(hits)+b'\xf0\xff\x05'+p(hits+8))
    c.add(b'\x61\x9d\xc2\x04\x00')
    c.label('pass')
    c.add(b'\x61\x9d\xe9')
    c.add(struct.pack('<i',target-(address+len(c.data)+4)))
    return c.finish()


class HeadVisibility:
    def __init__(self, memory, address):
        self.memory, self.address, self.slot = memory, address, 0
        self.synchronized = False
        self.selected = 0

    def show(self, force=False):
        self.selected = 0
        if force or not self.synchronized:
            self.memory.write(self.address + PAGE_SIZE, bytes(4))

    def hide_ranges(self, ranges):
        if len(ranges) > 128 or any(not 0 < start < end < 2**32 for start, end in ranges):
            raise ValueError('Invalid face/hair model ranges')
        self.slot ^= 1
        slot = self.address + PAGE_SIZE + 256 + self.slot * 1536
        payload = struct.pack('<I', len(ranges)) + b''.join(struct.pack('<II', *r) for r in ranges)
        self.memory.write(slot, payload)
        self.selected = slot
        if not self.synchronized:
            self.memory.write(self.address + PAGE_SIZE, struct.pack('<I', slot))

    def skipped_draws(self, kernel):
        raw = read(kernel, self.memory.handle, self.address + PAGE_SIZE + 4, 4)
        return struct.unpack('<I', raw)[0] if raw else None


@contextmanager
def installed_head_filter(kernel, pid, base, memory=None, recovery=None):
    owns_handle = memory is None
    if owns_handle:
        from doa5_freecam import GameMemory
        memory = GameMemory(kernel, pid)
    installed = []
    address = None
    try:
        # Validate all sites before modifying any, including unsupported game versions.
        specs = tuple(filter_patch_specs(base))
        for site, expected in specs:
            if read(kernel, memory.handle, site, len(expected)) != expected:
                raise RuntimeError('Unexpected primitive color draw call; interior filter was not installed')
        address = memory.allocate_memory(memory.handle, None, PAGE_SIZE * 2, 0x3000, 0x04)
        if not address:
            raise ct.WinError(ct.get_last_error())
        memory.write(address, draw_filter_stub(address, address + PAGE_SIZE,
                                               address + PAGE_SIZE + 4, base + PRIMITIVE_DRAW_RVA,
                                               pointer_offset=None, stack_pop=0, pass_guard=address+1024))
        memory.write(address + 256, draw_filter_stub(address + 256, address + PAGE_SIZE,
                                                   address + PAGE_SIZE + 4, base + PREPASS_DRAW_RVA,
                                                   pointer_offset=None, stack_pop=0, pass_guard=address+1024))
        memory.write(address + 512, unified_filter_stub(address + 512, address + PAGE_SIZE,
                                                       address + PAGE_SIZE + 4, base + 0x38E6F0,
                                                       pass_guard=address+1024))
        memory.write(address + 1024, viewport_guard(address+1024, address+PAGE_SIZE,
                                                  base+RENDERER_POINTER_RVA))
        aspect_raw = read(kernel, memory.handle, base+0xFC7310+0xC4, 4)
        aspect = struct.unpack('<f', aspect_raw)[0] if aspect_raw else 16/9
        aspect = aspect if math.isfinite(aspect) and 1.2 < aspect < 4 else 16/9
        memory.write(address+PAGE_SIZE+ASPECT_OFFSET, struct.pack('<I',round(aspect*1000)))
        memory.write(address + PAGE_SIZE + 8, b'PVI8')
        memory.protect(address, PAGE_SIZE, 0x20)
        memory.flush(memory.handle, address, PAGE_SIZE)
        if recovery:
            recovery.zero(address + PAGE_SIZE)
        for site, old in specs:
            if site == base + UNIFIED_SITE:
                new = struct.pack('<I', address+512)
            else:
                stub = address + (256 if site - base in PREPASS_CALLS else 0)
                new = b'\xe8' + struct.pack('<i', stub - site - 5)
            if recovery:
                recovery.patch(site, old, new)
            memory.patch(site, old, new, kernel)
            installed.append((site, old, new))
        yield HeadVisibility(memory, address)
    finally:
        if not memory.exited():
            if address:
                memory.write(address + PAGE_SIZE, bytes(4))
            for site, old, new in reversed(installed):
                memory.patch(site, new, old, kernel)
        if owns_handle:
            memory.close(memory.handle)
        # A render thread may still be returning through a restored vtable's stub.
        # Keep the small remote allocation alive until the game process exits.


def main():
    import argparse
    import time
    from probe_training_counters import open_game
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('pid', type=int)
    parser.add_argument('--player', type=int, choices=(1, 2), default=1)
    parser.add_argument('--seconds', type=float, default=10)
    args = parser.parse_args()
    with open_game(args.pid) as (kernel, handle, base, _):
        ranges = loaded_interior_ranges(kernel, handle, base, args.player - 1)
        if not ranges:
            raise RuntimeError('Could not identify the selected face and hair resources')
        print('Temporary head filter:', [(hex(a), hex(b)) for a, b in ranges], flush=True)
        with installed_head_filter(kernel, args.pid, base) as visibility:
            visibility.hide_ranges(ranges)
            time.sleep(args.seconds)
            hits, = struct.unpack('<I', read(kernel, handle, visibility.address + PAGE_SIZE + 4, 4))
            print('Filtered draws:', hits, flush=True)
        print('Restored all draw methods', flush=True)


if __name__ == '__main__':
    main()
