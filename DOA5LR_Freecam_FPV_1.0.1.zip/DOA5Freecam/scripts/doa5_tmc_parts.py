"""Runtime TMC part classifier. No third-party modules or game assets required."""
import struct

def unpack(fmt, data, at):
    return struct.unpack_from('<' + fmt, data, at)

def text(data, at, width):
    return data[at:at+width].split(b'\0', 1)[0].decode('ascii', errors='replace')

class Chunk:
    def __init__(self, data, at):
        self.at = at
        version, _, self.size, count, _, _, offsets, sizes, extra = unpack('9I', data, at+8)
        if version != 0x01010000 or not 0 < self.size <= len(data)-at:
            raise ValueError('Invalid TMC chunk')
        if count and (offsets < 0x30 or offsets+count*4 > self.size):
            raise ValueError('Invalid TMC offsets')
        relative = unpack(f'{count}I', data, at+offsets)
        if any(value >= self.size for value in relative):
            raise ValueError('Invalid TMC entry')
        self.entries = [at+value if value else None for value in relative]
        self.extra = at+extra if extra else None

def rig(data, chunks):
    names, palettes = [], {}
    for ordinal, at in enumerate(chunks['NodeLay'].entries):
        _, master, _, _ = unpack('4i', data, at+0x30)
        names.append(text(data, at+0x40, 128))
        if master == -1:
            for matrix in Chunk(data, at).entries:
                if matrix is not None:
                    group, count = unpack('2I', data, matrix)
                    palettes[group] = (ordinal, unpack(f'{count}I', data, matrix+0x50))
    return names, palettes

def meshes(data, chunks, names, palettes):
    for group_id, at in enumerate(chunks['MdlGeo'].entries):
        if at is None:
            continue
        group = Chunk(data, at)
        name = text(data, at+0x50, 16)
        _, palette = palettes.get(group_id, (None, ()))
        layouts = Chunk(data, group.extra).entries
        for part_id, obj in enumerate(group.entries):
            if obj is None:
                continue
            decl, = unpack('I', data, obj+0x38)
            _, _, _, start, count = unpack('5I', data, obj+0x6C)
            result = dict(group_id=group_id, group=name, part=part_id, vertices=count)
            # Hair only needs its group identity. Other parts need the same
            # active-weight and bounds measurements as the research auditor.
            if count and 'hair' not in name.lower() and 'zdmodel' not in name.lower():
                layout = layouts[decl]
                buffer_id, stride, field_count = unpack('3I', data, layout+0x30)
                fields = {usage: (offset, typ) for offset, typ, usage, _ in
                          (unpack('2xBxBx2B', data, layout+0x40+8*i) for i in range(field_count))}
                vertex = chunks['VtxLay'].entries[buffer_id] + start*stride
                if vertex < 0 or vertex+count*stride > len(data):
                    raise ValueError('Invalid TMC vertex stream')
                used, minimum, maximum = set(), [float('inf')]*3, [-float('inf')]*3
                position = fields.get(0)
                weight, indices = fields.get(1), fields.get(2)
                for i in range(count):
                    p = vertex+i*stride
                    if position and position[1] in (2, 3):
                        for axis, value in enumerate(unpack('3f', data, p+position[0])):
                            minimum[axis] = min(minimum[axis], value)
                            maximum[axis] = max(maximum[axis], value)
                    if weight and indices:
                        weights = unpack('4f' if weight[1] == 3 else '4B', data, p+weight[0])
                        bones = unpack('4B', data, p+indices[0])
                        used.update(b for b, w in zip(bones, weights) if w > 0)
                if position and position[1] in (2, 3):
                    result['local_bounds'] = [minimum, maximum]
                result['weighted_names'] = [names[palette[i]] for i in sorted(used)
                                            if i < len(palette) and palette[i] < len(names)]
            yield result
